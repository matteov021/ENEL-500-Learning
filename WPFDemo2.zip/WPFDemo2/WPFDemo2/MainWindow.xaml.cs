﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WPFDemo2
{
    public partial class MainWindow : Window
    {
        private Dictionary<string, List<double>> _tabData;
        private DispatcherTimer _timer;
        private Random _rand = new Random();
        private string _currentTab = "CPU";

        private Dictionary<string, string> _powerPhrases = new Dictionary<string, string>
        {
            { "p1", "System online!" },
            { "p2", "Engines running smoothly." },
            { "p3", "Processing request..." },
            { "p4", "Power levels stable." },
            { "p5", "All systems go!" }
        };

        public MainWindow()
        {
            InitializeComponent();

            // Initialize tab data
            _tabData = new Dictionary<string, List<double>>()
            {
                { "CPU", new List<double>() {5,7,6,8} },
                { "GPU", new List<double>() {3,6,4,5} },
                { "Memory", new List<double>() {2,3,5,6} },
                { "Disk", new List<double>() {1,2,3,2} },
            };

            DrawGraph();

            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromMilliseconds(500);
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            foreach (var key in _tabData.Keys)
            {
                var list = _tabData[key];
                list.Add(_rand.Next(2, 15));
                if (list.Count > 20) list.RemoveAt(0);
            }

            DrawGraph();
        }

        private void DrawGraph()
        {
            MainGraphCanvas.Children.Clear();

            if (!_tabData.ContainsKey(_currentTab)) return;
            var data = _tabData[_currentTab];

            double width = MainGraphCanvas.ActualWidth;
            double height = MainGraphCanvas.ActualHeight;

            if (width == 0 || height == 0) return;

            // ==== PARAMETERS ====
            int verticalGridLines = 5;
            int horizontalGridLines = 5;
            double maxValue = 15;
            double minValue = 0;

            // ==== DRAW BORDER ====
            Rectangle border = new Rectangle
            {
                Stroke = Brushes.Gray,
                StrokeThickness = 1,
                Width = width,
                Height = height
            };
            MainGraphCanvas.Children.Add(border);

            // ==== DRAW GRID LINES ====

            // Horizontal lines (Y)
            for (int i = 1; i < horizontalGridLines; i++)
            {
                double y = height * (i / (double)horizontalGridLines);

                Line line = new Line
                {
                    X1 = 0,
                    X2 = width,
                    Y1 = y,
                    Y2 = y,
                    Stroke = Brushes.DimGray,
                    StrokeThickness = 1,
                    StrokeDashArray = new DoubleCollection { 2, 2 }
                };
                MainGraphCanvas.Children.Add(line);

                // Y-axis labels
                double value = maxValue - (i / (double)horizontalGridLines) * maxValue;

                TextBlock label = new TextBlock
                {
                    Text = value.ToString("0"),
                    Foreground = Brushes.Black,
                    Margin = new Thickness(-20, y - 8, 0, 0)
                };

                MainGraphCanvas.Children.Add(label);
            }

            // Vertical lines (X)
            int count = data.Count;
            for (int i = 1; i < verticalGridLines; i++)
            {
                double x = width * (i / (double)verticalGridLines);

                Line line = new Line
                {
                    X1 = x,
                    X2 = x,
                    Y1 = 0,
                    Y2 = height,
                    Stroke = Brushes.DimGray,
                    StrokeThickness = 1,
                    StrokeDashArray = new DoubleCollection { 2, 2 }
                };
                MainGraphCanvas.Children.Add(line);

                // X-axis labels
                int idx = (int)(i / (double)verticalGridLines * count);

                TextBlock label = new TextBlock
                {
                    Text = idx.ToString(),
                    Foreground = Brushes.Black,
                    Margin = new Thickness(x - 5, height , 0, 0)
                };

                MainGraphCanvas.Children.Add(label);
            }

            // ==== DRAW DATA LINE ====
            Polyline lineGraph = new Polyline
            {
                Stroke = Brushes.Lime,
                StrokeThickness = 2
            };

            for (int i = 0; i < data.Count; i++)
            {
                double x = i * (width / (data.Count - 1));
                double normalized = data[i] / maxValue;  // normalize 0 → 1
                double y = height - (normalized * height);

                lineGraph.Points.Add(new Point(x, y));
            }

            MainGraphCanvas.Children.Add(lineGraph);
        }


        private void HamburgerButton_Click(object sender, RoutedEventArgs e)
        {
            MenuItems.Visibility = MenuItems.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
        }

        private void Tab_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as System.Windows.Controls.Button;
            _currentTab = button.Tag.ToString();
            DrawGraph();
        }

        private void PowerButton_Click(object sender, RoutedEventArgs e)
        {
            if (ParameterDropdown.SelectedItem is ComboBoxItem item)
            {
                string key = item.Content.ToString();

                if (_powerPhrases.ContainsKey(key))
                    MessageBox.Show(_powerPhrases[key]);
                else
                    MessageBox.Show("No phrase found.");
            }
            else
            {
                MessageBox.Show("Select a parameter first.");
            }
        }
    }
}