﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using TestDemo3.Views;
using TestDemo3.Views; // Don't forget this using statement

namespace TestDemo3
{
    public partial class MainWindow : Window
    {
        private bool _isMenuOpen = false;

        public MainWindow()
        {
            InitializeComponent();
            // Load default page
            ContentHost.Content = new HomeView();
        }

        private void Nav_Click(object sender, RoutedEventArgs e)
        {
            string tab = (sender as Button)?.Tag?.ToString();

            switch (tab)
            {
                case "Home":
                    ContentHost.Content = new HomeView();
                    break;
                case "Flash":
                    ContentHost.Content = new FlashView();
                    break;
                // Add other views here as you create them:
                // case "Settings": ContentHost.Content = new SettingsView(); break;
                // case "Graphs": ContentHost.Content = new GraphsView(); break;
                default:
                    // Fallback for pages you haven't converted yet
                    ContentHost.Content = new TextBlock { Text = tab + " (Coming Soon)", FontSize = 30, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                    break;
            }
        }

        private void HamburgerButton_Click(object sender, RoutedEventArgs e)
        {
            double from = NavColumn.Width.Value;
            double to = _isMenuOpen ? 60 : 200;

            var anim = new GridLengthAnimation
            {
                From = new GridLength(from),
                To = new GridLength(to),
                Duration = TimeSpan.FromMilliseconds(200),
            };

            NavColumn.BeginAnimation(ColumnDefinition.WidthProperty, anim);
            _isMenuOpen = !_isMenuOpen;
        }

        private void PowerButton_Click(object sender, RoutedEventArgs e) => MessageBox.Show("Power");
        private void ConnectButton_Click(object sender, RoutedEventArgs e) => MessageBox.Show("Connect");
    }

    // Helper helper class for animating GridLength (Grid columns)
    // Put this class at the bottom of the file or in a separate file
    public class GridLengthAnimation : AnimationTimeline
    {
        public GridLength From { get; set; }
        public GridLength To { get; set; }

        public override Type TargetPropertyType => typeof(GridLength);

        protected override Freezable CreateInstanceCore() => new GridLengthAnimation();

        public override object GetCurrentValue(object defaultOriginValue, object defaultDestinationValue, AnimationClock animationClock)
        {
            double fromVal = From.Value;
            double toVal = To.Value;

            if (fromVal > toVal)
                return new GridLength((1 - animationClock.CurrentProgress.Value) * (fromVal - toVal) + toVal);
            else
                return new GridLength(animationClock.CurrentProgress.Value * (toVal - fromVal) + fromVal);
        }
    }
}