﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;
using System.Windows.Threading;
using WPFDemo.Helpers;

namespace WPFDemo.ViewModels
{
    public class TaskManagerViewModel : INotifyPropertyChanged
    {
        private readonly Random _rnd = new Random();

        public ObservableCollection<ProcessViewModel> Processes { get; set; }

        public ICommand AddProcessCommand { get; }
        public ICommand RemoveProcessCommand { get; }

        private ProcessViewModel _selectedProcess;
        public ProcessViewModel SelectedProcess
        {
            get => _selectedProcess;
            set
            {
                if (_selectedProcess != value)
                {
                    _selectedProcess = value;
                    OnPropertyChanged(nameof(SelectedProcess));
                }
            }
        }

        private readonly DispatcherTimer _timer;

        public TaskManagerViewModel()
        {
            Processes = new ObservableCollection<ProcessViewModel>
            {
                new ProcessViewModel { Name = "explorer.exe", CPUUsage = 5, Memory = 120 },
                new ProcessViewModel { Name = "chrome.exe", CPUUsage = 15, Memory = 350 }
            };

            AddProcessCommand = new RelayCommand(_ => AddProcess());
            RemoveProcessCommand = new RelayCommand(_ => RemoveSelectedProcess(), _ => SelectedProcess != null);

            // Setup timer for live updates
            _timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            _timer.Tick += (s, e) => UpdateProcesses();
            _timer.Start();
        }

        private void AddProcess()
        {
            Processes.Add(new ProcessViewModel
            {
                Name = "Process" + _rnd.Next(1000, 9999) + ".exe",
                CPUUsage = _rnd.Next(1, 50),
                Memory = _rnd.Next(50, 500)
            });
        }

        private void RemoveSelectedProcess()
        {
            if (SelectedProcess != null)
            {
                Processes.Remove(SelectedProcess);
                SelectedProcess = null;
            }
        }

        private void UpdateProcesses()
        {
            foreach (var process in Processes)
            {
                // Randomly change CPU and Memory values
                process.CPUUsage = _rnd.Next(1, 100);
                process.Memory = _rnd.Next(50, 500);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
