﻿using System.ComponentModel;

namespace WPFDemo.ViewModels
{
    public class ProcessViewModel : INotifyPropertyChanged
    {
        private string _name;
        private int _cpuUsage;
        private int _memory;

        public string Name
        {
            get => _name;
            set { if (_name != value) { _name = value; OnPropertyChanged(nameof(Name)); } }
        }

        public int CPUUsage
        {
            get => _cpuUsage;
            set { if (_cpuUsage != value) { _cpuUsage = value; OnPropertyChanged(nameof(CPUUsage)); } }
        }

        public int Memory
        {
            get => _memory;
            set { if (_memory != value) { _memory = value; OnPropertyChanged(nameof(Memory)); } }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
