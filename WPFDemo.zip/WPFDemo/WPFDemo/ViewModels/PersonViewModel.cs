﻿using System.ComponentModel;
using System.Windows.Input;
using WPFDemo.Helpers;

namespace WPFDemo.ViewModels
{
    public class PersonViewModel : INotifyPropertyChanged
    {
        private string _name = "Alice";
        private int _age = 30;

        public string Name
        {
            get => _name;
            set { if (_name != value) { _name = value; OnPropertyChanged(nameof(Name)); } }
        }

        public int Age
        {
            get => _age;
            set { if (_age != value) { _age = value; OnPropertyChanged(nameof(Age)); } }
        }

        // Commands
        public ICommand CelebrateBirthdayCommand { get; }
        public ICommand ResetAgeCommand { get; }

        public PersonViewModel()
        {
            CelebrateBirthdayCommand = new RelayCommand(_ => CelebrateBirthday(), _ => Age < 100);
            ResetAgeCommand = new RelayCommand(_ => Age = 30);
        }

        public void CelebrateBirthday() => Age += 1;

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
