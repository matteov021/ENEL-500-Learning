﻿using System.Windows;
using WPFDemo.ViewModels;

namespace WPFDemo.Steps
{
    public partial class Step16Window : Window
    {
        public Step16Window()
        {
            InitializeComponent();
            this.DataContext = new TaskManagerViewModel();
        }
    }
}