﻿using System.Windows;
using WPFDemo.ViewModels;

namespace WPFDemo.Steps
{
    public partial class Step14Window : Window
    {
        public Step14Window()
        {
            InitializeComponent();
            this.DataContext = new TaskManagerViewModel();
        }
    }
}
