﻿using System.Windows;
using WPFDemo.ViewModels;

namespace WPFDemo.Steps
{
    public partial class Step13Window : Window
    {
        public Step13Window()
        {
            InitializeComponent();
            this.DataContext = new PersonViewModel(); // Everything wired via commands
        }
    }
}
