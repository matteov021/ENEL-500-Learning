﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WPFDemo3
{
    public partial class MainWindow : Window
    {
        // ============================
        // Fields
        // ============================
        private bool _isMenuOpen = false;

        // DependencyProperty for navigation width
        public static readonly DependencyProperty NavWidthProperty = DependencyProperty.Register(nameof(NavWidth), typeof(double), 
                                                                     typeof(MainWindow), new PropertyMetadata(60.0, OnNavWidthChanged));

        // ============================
        // Properties
        // ============================
        public double NavWidth
        {
            get => (double)GetValue(NavWidthProperty);
            set => SetValue(NavWidthProperty, value);
        }

        // ============================
        // Constructor
        // ============================
        public MainWindow()
        {
            InitializeComponent();
            LoadHomePage();
        }

        // ============================
        // Event Handlers
        // ============================

        private static void OnNavWidthChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {

            // Update the NavColumn width
            if (d is MainWindow win)
            {
                win.NavColumn.Width = new GridLength((double)e.NewValue);
            }
        }

        private void HamburgerButton_Click(object sender, RoutedEventArgs e)
        {
            // Animate the navigation width
            double from = NavWidth;
            double to = _isMenuOpen ? 60 : 200;

            // Create the animation
            var anim = new DoubleAnimation
            {
                From = from,
                To = to,
                Duration = TimeSpan.FromMilliseconds(200),
                EasingFunction = new QuadraticEase()
            };

            // Start the animation
            BeginAnimation(NavWidthProperty, anim);
            _isMenuOpen = !_isMenuOpen;
        }

        private void Nav_Click(object sender, RoutedEventArgs e)
        {
            // Determine which tab was clicked
            string tab = (sender as Button)?.Tag?.ToString();

            // Load the corresponding page
            switch (tab)
            {
                case "Home": LoadHomePage(); break;
                case "Settings": LoadSettingsPage(); break;
                case "Graphs": LoadGraphsPage(); break;
                case "Flash": LoadFlashPage(); break;
                case "Configuration": LoadConfigurationPage(); break;
                case "Data Logging": LoadDataLoggingPage(); break;
                default:

                    ContentHost.Children.Clear();

                    // Simple card with tab name
                    var card = new Border { Style = (Style)FindResource("ContentCardStyle") };
                    card.Child = new TextBlock
                    {
                        Text = tab,
                        FontSize = 28,
                        VerticalAlignment = VerticalAlignment.Center,
                        HorizontalAlignment = HorizontalAlignment.Center
                    };
                    ContentHost.Children.Add(card);
                    break;
            }
        }

        private void PowerButton_Click(object sender, RoutedEventArgs e)
        {
            // Handle power button click
            MessageBox.Show("Power button pressed!");
        }

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            // Handle connect button click
            MessageBox.Show("Connect button pressed!");
        }

        // ============================
        // Page Loaders
        // ============================

        private void LoadHomePage()
        {
            // Clear existing content
            ContentHost.Children.Clear();

            // Create root grid
            var root = new Grid { Margin = new Thickness(10) };
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // Header
            var header = new TextBlock
            {
                Text = "Overview",
                FontSize = 26,
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 10)
            };
            root.Children.Add(header);

            // Info cards
            var cardPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                Margin = new Thickness(0, 0, 0, 10)
            };

            // Add individual info cards
            Grid.SetRow(cardPanel, 1);
            cardPanel.Children.Add(CreateInfoCard("Status", "Idle", "LimeGreen"));
            cardPanel.Children.Add(CreateInfoCard("Connection", "Disconnected", "Orange"));
            cardPanel.Children.Add(CreateInfoCard("System", "Normal", "DodgerBlue"));
            root.Children.Add(cardPanel);

            // Graph placeholder
            var graphCard = new Border
            {
                Style = (Style)FindResource("ContentCardStyle"),
                Margin = new Thickness(0, 0, 0, 10),
                Child = new TextBlock
                {
                    Text = "Live Graph Placeholder",
                    FontSize = 22,
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center
                }
            };

            Grid.SetRow(graphCard, 2);
            root.Children.Add(graphCard);
            ContentHost.Children.Add(root);
        }

        private void LoadSettingsPage()
        {
            // Clear existing content
            ContentHost.Children.Clear();

            // Main settings card
            var mainCard = new Border
            {
                Style = (Style)FindResource("ContentCardStyle"),
                Padding = new Thickness(20),
                Margin = new Thickness(0)
            };

            // Settings stack
            var stack = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(5),
                Children =
                {
                    // Header
                    new TextBlock
                    {
                        Text = "Settings",
                        FontSize = 26,
                        Margin = new Thickness(0,0,0,20),
                        FontWeight = FontWeights.SemiBold
                    },

                    // General Options
                    CreateToggleRow("Temperature Units", "Celsius", "Fahrenheit"),
                    CreateToggleRow("Theme", "Light", "Dark"),
                    CreateSeparator(),
                    CreateCategoryHeader("System Options"),
                    CreateSettingRow("Auto-Connect", "Connect automatically on startup (disabled)"),
                    CreateSettingRow("Diagnostics Mode", "Detailed logging disabled"),
                    CreateSeparator(),
                }
            };

            mainCard.Child = stack;
            ContentHost.Children.Add(mainCard);
        }

        private void LoadGraphsPage()
        {
            // Clear existing content
            ContentHost.Children.Clear();

            // Root grid
            var root = new Grid { Margin = new Thickness(10) };
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // Graph card
            var graphCard = new Border
            {
                Style = (Style)FindResource("ContentCardStyle"),
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Stretch,
                Child = CreateGraphPlaceholder()
            };
            Grid.SetRow(graphCard, 0);
            root.Children.Add(graphCard);

            // Control panel
            var controlPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Left,
                Margin = new Thickness(0, 10, 0, 0),
                Children =
                {
                    CreateDropdown("Select Outlet:", new string[] { "Whole System", "Outlet 1", "Outlet 2", "Outlet 3", "Outlet 4"}),
                    CreateDropdown("Metric:", new string[] {"Wattage", "Current", "Voltage"})
                }
            };
            Grid.SetRow(controlPanel, 1);
            root.Children.Add(controlPanel);
            ContentHost.Children.Add(root);
        }

        private void LoadFlashPage()
        {
            // Clear existing content
            ContentHost.Children.Clear();

            // Root grid
            var root = new Grid { Margin = new Thickness(10) };
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Header
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Firmware
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Device
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Buttons
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Progress
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // Logs

            // Header
            var headerCard = new Border
            {
                Style = (Style)FindResource("ContentCardStyle"),
                Margin = new Thickness(0, 0, 0, 10),
                Child = new StackPanel
                {
                    Children =
                    {
                        // Header Text
                        new TextBlock
                        {
                            Text = "Flash Firmware",
                            FontSize = 26,
                            FontWeight = FontWeights.SemiBold
                        },

                        // Description
                        new TextBlock
                        {
                            Text = "Update the microcontroller firmware. Ensure the device is connected before starting.",
                            FontSize = 14,
                            Foreground = Brushes.Gray,
                            TextWrapping = TextWrapping.Wrap,
                            Margin = new Thickness(0,5,0,0)
                        }
                    }
                }
            };
            Grid.SetRow(headerCard, 0);
            root.Children.Add(headerCard);

            // Firmware selector
            var firmwareCard = new Border
            {
                Style = (Style)FindResource("ContentCardStyle"),
                Margin = new Thickness(0, 0, 0, 10),
                Child = CreateDropdown("Select Firmware:", new string[] { "1.0.1", "1.1.0-beta", "1.2.0" })
            };
            Grid.SetRow(firmwareCard, 1);
            root.Children.Add(firmwareCard);

            // Device info card
            var deviceCard = new Border
            {
                Style = (Style)FindResource("ContentCardStyle"),
                Margin = new Thickness(0, 0, 0, 10),
                Child = new StackPanel
                {
                    Children =
                    {
                        // Device Info
                        new TextBlock
                        {
                            Text = "Device Status",
                            FontSize = 18,
                            FontWeight = FontWeights.SemiBold,
                            Margin = new Thickness(0,0,0,5)
                        },

                        // Details
                        new TextBlock { Text = "Connected: Yes", FontSize = 14 },
                        new TextBlock { Text = "Serial Number: SN-12345-001", FontSize = 14 },
                        new TextBlock { Text = "Current Firmware: 1.0.0", FontSize = 14 }
                    }
                }
            };
            Grid.SetRow(deviceCard, 2);
            root.Children.Add(deviceCard);

            // Buttons
            var buttonPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 10),
                Children =
                {
                    // Action Buttons
                    new Button { Content = "Start Flash", Width = 120, Margin = new Thickness(0,0,10,0), Style = (Style)FindResource("BlueButtonStyle") },
                    new Button { Content = "Cancel", Width = 120, Style = (Style)FindResource("GreenButtonStyle") }
                }
            };
            Grid.SetRow(buttonPanel, 3);
            root.Children.Add(buttonPanel);

            // Progress
            var progressCard = new Border
            {
                Style = (Style)FindResource("ContentCardStyle"),
                Margin = new Thickness(0, 0, 0, 10),
                Child = new StackPanel
                {
                    Children =
                    {
                        // Progress Bar
                        new ProgressBar { Name = "FlashProgress", Height = 20, Minimum = 0, Maximum = 100, Value = 0 },
                        new TextBlock { Text = "Status: Idle", FontSize = 14, Margin = new Thickness(0,5,0,0) }
                    }
                }
            };
            Grid.SetRow(progressCard, 4);
            root.Children.Add(progressCard);

            // Log Output
            var logCard = new Border
            {
                // Log TextBox
                Style = (Style)FindResource("ContentCardStyle"),
                Child = new TextBox
                {
                    Name = "FlashLog",
                    Text = "Logs will appear here...",
                    FontSize = 12,
                    IsReadOnly = true,
                    TextWrapping = TextWrapping.Wrap,
                    VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                    AcceptsReturn = true
                }
            };
            Grid.SetRow(logCard, 5);
            root.Children.Add(logCard);
            ContentHost.Children.Add(root);
        }

        private void LoadConfigurationPage()
        {
            // Clear existing content
            ContentHost.Children.Clear();

            // Main configuration card
            var mainCard = new Border
            {
                Style = (Style)FindResource("ContentCardStyle"),
                Padding = new Thickness(20),
                Margin = new Thickness(0)
            };

            // Configuration stack
            var stack = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Children =
                {
                    // Header
                    new TextBlock
                    {
                        Text = "Configuration",
                        FontSize = 26,
                        FontWeight = FontWeights.SemiBold,
                        Margin = new Thickness(0,0,0,20)
                    },

                    // Configuration Rows
                    CreateConfigRow("Select Outlet:", new string[] { "Whole System", "Outlet 1", "Outlet 2", "Outlet 3", "Outlet 4"},
                                    "Current State:", new string[] {"On", "Off"}),

                    CreateSeparator(),

                    // Relay Settings
                    CreateConfigRow("Select Relay:", new string[] {"All Relays", "Relay 1", "Relay 2"},
                                    "Current State:", new string[] {"Enabled", "Disabled"}),

                    CreateSeparator(),

                    // Current Limit Settings
                    CreateConfigRow("Current Limit Target:", new string[] { "Whole System", "Outlet 1", "Outlet 2", "Outlet 3", "Outlet 4"},
                                    "Current Limit:", new string[] {"5A","10A","15A","20A"})
                }
            };

            mainCard.Child = stack;
            ContentHost.Children.Add(mainCard);
        }

        private void LoadDataLoggingPage()
        {
            // Clear existing content
            ContentHost.Children.Clear();

            // Root grid
            var root = new Grid { Margin = new Thickness(10) };
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Header
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Controls
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Status
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // Log Preview
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Export / Clear

            // Header
            var headerCard = new Border
            {
                // Header Card
                Style = (Style)FindResource("ContentCardStyle"),
                Margin = new Thickness(0, 0, 0, 10),
                Child = new StackPanel
                {
                    Children =
                    {
                        // Header Text
                        new TextBlock { Text = "Data Logging", FontSize = 26, FontWeight = FontWeights.SemiBold },
                        new TextBlock
                        {
                            // Description
                            Text = "Capture and review live data from your device. Logs can be exported to CSV or JSON.",
                            FontSize = 14,
                            Foreground = Brushes.Gray,
                            TextWrapping = TextWrapping.Wrap,
                            Margin = new Thickness(0,5,0,0)
                        }
                    }
                }
            };
            Grid.SetRow(headerCard, 0);
            root.Children.Add(headerCard);

            // Controls
            var controlPanel = new StackPanel
            {
                // Control Buttons and Dropdowns
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 10),
                Children =
                {
                    // Action Buttons
                    new Button { Content="Start Logging", Width=120, Margin=new Thickness(0,0,10,0), Style=(Style)FindResource("BlueButtonStyle") },
                    new Button { Content="Stop Logging", Width=120, Style=(Style)FindResource("GreenButtonStyle") },
                    CreateDropdown("Interval:", new string[]{ "1s", "5s", "10s", "30s" }),
                    CreateDropdown("File Format:", new string[]{ "CSV", "JSON" })
                }
            };
            Grid.SetRow(controlPanel, 1);
            root.Children.Add(controlPanel);

            // Status
            var statusCard = new Border
            {
                // Status Card
                Style = (Style)FindResource("ContentCardStyle"),
                Margin = new Thickness(0, 0, 0, 10),
                Child = new StackPanel
                {
                    // Status Details
                    Children =
                    {
                        new TextBlock { Text="Status: Stopped", FontSize=14 },
                        new TextBlock { Text="Last file saved: N/A", FontSize=14 }
                    }
                }
            };
            Grid.SetRow(statusCard, 2);
            root.Children.Add(statusCard);

            // Log Preview
            var logPreview = new Border
            {
                // Log Preview TextBox
                Style = (Style)FindResource("ContentCardStyle"),
                Child = new TextBox
                {
                    Name = "LogPreview",
                    Text = "Logs will appear here...",
                    FontSize = 12,
                    IsReadOnly = true,
                    TextWrapping = TextWrapping.Wrap,
                    VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                    AcceptsReturn = true
                }
            };
            Grid.SetRow(logPreview, 3);
            root.Children.Add(logPreview);

            // Export / Clear
            var exportPanel = new StackPanel
            {
                // Export and Clear Buttons
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 10, 0, 0),
                Children =
                {
                    // Action Buttons
                    new Button { Content="Export Logs", Width=120, Margin=new Thickness(0,0,10,0), Style=(Style)FindResource("BlueButtonStyle") },
                    new Button { Content="Clear Preview", Width=120, Style=(Style)FindResource("GreenButtonStyle") }
                }
            };
            Grid.SetRow(exportPanel, 4);
            root.Children.Add(exportPanel);
            ContentHost.Children.Add(root);
        }

        // ============================
        // Helper Methods
        // ============================

        private UIElement CreateConfigRow(string selectLabel, string[] selectOptions, string currentLabel, string[] valueOptions)
        {
            // Create dropdowns
            var selectDropdown = CreateDropdown(selectLabel, selectOptions);
            var currentDropdown = CreateDropdown(currentLabel, valueOptions);

            // Create Set button
            var setButton = new Button
            {
                Content = "Set",
                Width = 80,
                Height = 28,
                Margin = new Thickness(10, 0, 0, 0),
                Style = (Style)FindResource("BlueButtonStyle")
            };

            // Set button click event
            setButton.Click += (s, e) =>
            {
                if (currentDropdown is StackPanel sp && sp.Children[1] is ComboBox cb)
                {
                    string selectedValue = cb.SelectedItem?.ToString() ?? "<none>";
                    MessageBox.Show($"Setting {selectLabel} to {selectedValue}");
                }
            };

            // Return combined row
            return new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5),
                Children = { selectDropdown, currentDropdown, setButton }
            };
        }

        private UIElement CreateToggleRow(string title, string leftOption, string rightOption)
        {
            // Create label
            var label = new TextBlock
            {
                Text = title,
                FontSize = 16,
                Margin = new Thickness(0, 10, 0, 10),
                FontWeight = FontWeights.SemiBold
            };

            // Create toggle components
            var left = new TextBlock { Text = leftOption, VerticalAlignment = VerticalAlignment.Center };
            var right = new TextBlock { Text = rightOption, VerticalAlignment = VerticalAlignment.Center };

            // Create toggle switch
            var toggle = new Border
            {
                Width = 50,
                Height = 24,
                Background = new SolidColorBrush(Color.FromRgb(200, 200, 200)),
                CornerRadius = new CornerRadius(12),
                Margin = new Thickness(10, 0, 10, 0),
                Child = new Border
                {
                    Width = 22,
                    Height = 22,
                    Background = Brushes.White,
                    CornerRadius = new CornerRadius(11),
                    Margin = new Thickness(1),
                    HorizontalAlignment = HorizontalAlignment.Left
                }
            };

            // Toggle click event
            return new StackPanel
            {
                Orientation = Orientation.Vertical,
                Children =
                {
                    label,
                    new StackPanel
                    {
                        Orientation=Orientation.Horizontal,
                        VerticalAlignment=VerticalAlignment.Center,
                        Children = { left, toggle, right }
                    }
                }
            };
        }

        private UIElement CreateSettingRow(string title, string desc)
        {
            // Return setting description
            return new StackPanel
            {
                Margin = new Thickness(0, 0, 0, 10),
                Children =
                {
                    new TextBlock { Text=title, FontSize=15, FontWeight=FontWeights.Medium },
                    new TextBlock { Text=desc, FontSize=12, Foreground=Brushes.Gray }
                }
            };
        }

        private UIElement CreateCategoryHeader(string title)
        {
            // Return category header
            return new TextBlock
            {
                Text = title,
                FontSize = 18,
                Margin = new Thickness(0, 10, 0, 10),
                FontWeight = FontWeights.SemiBold
            };
        }

        private UIElement CreateSeparator()
        {
            // Return separator line
            return new Border
            {
                Height = 1,
                Background = new SolidColorBrush(Color.FromRgb(230, 230, 230)),
                Margin = new Thickness(0, 20, 0, 20)
            };
        }

        private UIElement CreateDropdown(string labelText, string[] options)
        {
            // Create label
            var label = new TextBlock
            {
                Text = labelText,
                FontSize = 14,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(5, 0, 5, 0)
            };

            // Create ComboBox
            var comboBox = new ComboBox
            {
                Width = 140,
                Height = 28,
                Margin = new Thickness(0, 0, 20, 0),
                ItemsSource = options,
                SelectedIndex = 0,
                VerticalContentAlignment = VerticalAlignment.Center,
                Padding = new Thickness(5, 0, 5, 0)
            };

            // Return combined element
            return new StackPanel
            {
                Orientation = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
                Children = { label, comboBox }
            };
        }

        private Border CreateInfoCard(string title, string value, string statusColor = "Green")
        {
            // Create status dot
            var statusDot = new Ellipse
            {
                Width = 12,
                Height = 12,
                Margin = new Thickness(0, 0, 6, 0),
                Fill = (Brush)new BrushConverter().ConvertFromString(statusColor)
            };

            // Create title row
            var titleRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Children =
                {
                    statusDot,
                    new TextBlock { Text=title, FontSize=14, Foreground=Brushes.Gray }
                }
            };

            // Return info card
            return new Border
            {
                Style = (Style)FindResource("ContentCardStyle"),
                Width = 180,
                Height = 90,
                Margin = new Thickness(0, 0, 10, 0),
                Child = new StackPanel
                {
                    Margin = new Thickness(5),
                    Children =
                    {
                        titleRow,
                        new TextBlock { Text=value, FontSize=22, FontWeight=FontWeights.SemiBold, Margin=new Thickness(0,5,0,0) }
                    }
                }
            };
        }

        private UIElement CreateGraphPlaceholder()
        {
            // Create a simple graph placeholder using Canvas
            var grid = new Grid { Background = Brushes.White };
            var canvas = new Canvas { HorizontalAlignment = HorizontalAlignment.Stretch, VerticalAlignment = VerticalAlignment.Stretch };
            grid.Children.Add(canvas);

            // Draw gridlines and sample polyline
            canvas.Loaded += (s, e) =>
            {
                double width = canvas.ActualWidth;
                double height = canvas.ActualHeight;

                // Vertical gridlines
                for (int i = 0; i <= 6; i++)
                {
                    canvas.Children.Add(new Line
                    {
                        X1 = i * width / 6,
                        Y1 = 0,
                        X2 = i * width / 6,
                        Y2 = height,
                        Stroke = Brushes.LightGray,
                        StrokeThickness = 1
                    });
                }

                // Horizontal gridlines
                for (int i = 0; i <= 6; i++)
                {
                    canvas.Children.Add(new Line
                    {
                        X1 = 0,
                        Y1 = i * height / 6,
                        X2 = width,
                        Y2 = i * height / 6,
                        Stroke = Brushes.LightGray,
                        StrokeThickness = 1
                    });
                }

                // Sample polyline
                double[] sampleY = { 250, 180, 200, 150, 120, 80, 60 };
                var polyline = new Polyline { Stroke = Brushes.DodgerBlue, StrokeThickness = 2 };

                // Plot points
                for (int i = 0; i < sampleY.Length; i++)
                {
                    polyline.Points.Add(new System.Windows.Point(i * width / (sampleY.Length - 1), sampleY[i] / 300.0 * height));
                }
                canvas.Children.Add(polyline);
            };

            return grid;
        }
    }
}