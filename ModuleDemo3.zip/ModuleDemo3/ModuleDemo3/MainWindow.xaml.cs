﻿using ModuleDemo3.Pages;
using System.Windows;
using System.Windows.Controls;

namespace ModuleDemo3
{
    public partial class MainWindow : Window
    {

        // Pre-instantiate pages for faster navigation
        private readonly HomePage _homePage = new HomePage();
        private readonly GraphsPage _graphsPage = new GraphsPage();
        private readonly DataLoggingPage _dataLoggingPage = new DataLoggingPage();
        private readonly ConfigurationPage _configurationPage = new ConfigurationPage();
        private readonly SettingsPage _settingsPage = new SettingsPage();

        // Sidebar state
        private bool _isSidebarCollapsed = false;

        // Constructor
        public MainWindow()
        {
            InitializeComponent();
            ContentHost.Content = _homePage;
        }

        // Navigation button click handler
        private void Nav_Click(object sender, RoutedEventArgs e)
        {
            var tag = ((Button)sender).Tag.ToString();

            ContentHost.Content = tag switch
            {
                "Home" => _homePage,
                "Graphs" => _graphsPage,
                "DataLogging" => _dataLoggingPage,
                "Configuration" => _configurationPage,
                "Settings" => _settingsPage,
                _ => null
            };
        }

        // Toggle sidebar button click handler
        private void ToggleSidebar_Click(object sender, RoutedEventArgs e)
        {
            double from = SidebarColumn.Width.Value;
            double to = _isSidebarCollapsed ? 240 : 100;

            // Create and start the animation
            var animation = new GridLengthAnimation
            {
                From = new GridLength(from),
                To = new GridLength(to),
                Duration = TimeSpan.FromMilliseconds(220)
            };

            SidebarColumn.BeginAnimation(ColumnDefinition.WidthProperty, animation);
            _isSidebarCollapsed = !_isSidebarCollapsed;
        }
    }
}
