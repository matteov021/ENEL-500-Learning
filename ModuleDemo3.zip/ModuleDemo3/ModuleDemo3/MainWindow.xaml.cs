﻿using ModuleDemo3.Pages;
using System.Windows;
using System.Windows.Controls;

namespace ModuleDemo3
{
    public partial class MainWindow : Window
    {
        // Constructor
        public MainWindow()
        {
            InitializeComponent();
            ContentHost.Content = new HomePage();
        }

        // Sidebar state
        private bool _isSidebarCollapsed = false;

        // Navigation button click handler
        private void Nav_Click(object sender, RoutedEventArgs e)
        {
            var tag = ((System.Windows.Controls.Button)sender).Tag.ToString();

            ContentHost.Content = tag switch
            {
                "Home" => new HomePage(),
                "Graphs" => new GraphsPage(),
                "DataLogging" => new DataLoggingPage(),
                "Configuration" => new ConfigurationPage(),
                "Settings" => new SettingsPage(),
                _ => null
            };
        }

        // Toggle sidebar button click handler
        private void ToggleSidebar_Click(object sender, RoutedEventArgs e)
        {
            double from = SidebarColumn.Width.Value;
            double to = _isSidebarCollapsed ? 240 : 100;

            // Create and start the animation
            var animation = new GridLengthAnimation
            {
                From = new GridLength(from),
                To = new GridLength(to),
                Duration = TimeSpan.FromMilliseconds(220)
            };

            SidebarColumn.BeginAnimation(ColumnDefinition.WidthProperty, animation);
            _isSidebarCollapsed = !_isSidebarCollapsed;
        }
    }
}
