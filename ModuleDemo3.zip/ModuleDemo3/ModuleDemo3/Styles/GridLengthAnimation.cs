﻿using System.Windows;
using System.Windows.Media.Animation;

public class GridLengthAnimation : AnimationTimeline
{
    // Target property type
    public override Type TargetPropertyType => typeof(GridLength);

    // Create a new instance of the animation
    protected override Freezable CreateInstanceCore() => new GridLengthAnimation();

    // DependencyProperty for From
    public static readonly DependencyProperty FromProperty = DependencyProperty.Register("From", typeof(GridLength), typeof(GridLengthAnimation));

    // DependencyProperty for To
    public static readonly DependencyProperty ToProperty = DependencyProperty.Register("To", typeof(GridLength), typeof(GridLengthAnimation));

    // Calculate the current value of the animation
    public override object GetCurrentValue(object defaultOriginValue, object defaultDestinationValue, AnimationClock animationClock)
    {
        double from = From.Value;
        double to = To.Value;

        return new GridLength(from + (to - from) * animationClock.CurrentProgress!.Value, GridUnitType.Pixel);
    }

    // From property
    public GridLength From
    {
        get => (GridLength)GetValue(FromProperty);
        set => SetValue(FromProperty, value);
    }

    // To property
    public GridLength To
    {
        get => (GridLength)GetValue(ToProperty);
        set => SetValue(ToProperty, value);
    }
}
