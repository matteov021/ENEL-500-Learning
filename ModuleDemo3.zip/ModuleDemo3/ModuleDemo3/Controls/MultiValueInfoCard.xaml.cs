﻿using ModuleDemo3.Core;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ModuleDemo3.Controls
{
    public partial class MultiValueInfoCard : UserControl
    {

        // Constructor
        public MultiValueInfoCard()
        {
            InitializeComponent();
        }

        // Dependency Properties
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register(nameof(Title), typeof(string), typeof(MultiValueInfoCard));

        public static readonly DependencyProperty RegisterIndexProperty =
            DependencyProperty.Register(nameof(RegisterIndex), typeof(int), typeof(MultiValueInfoCard), new PropertyMetadata(0));

        public static readonly DependencyProperty StatusColorProperty =
            DependencyProperty.Register(nameof(StatusColor), typeof(Brush), typeof(MultiValueInfoCard));

        public static readonly DependencyProperty AmperageProperty =
            DependencyProperty.Register(nameof(Amperage), typeof(string), typeof(MultiValueInfoCard));

        public static readonly DependencyProperty VoltageProperty =
            DependencyProperty.Register(nameof(Voltage), typeof(string), typeof(MultiValueInfoCard));

        public static readonly DependencyProperty WattageProperty =
            DependencyProperty.Register(nameof(Wattage), typeof(string), typeof(MultiValueInfoCard));

        // Title Getter and Setter
        public string Title
        {
            get => (string)GetValue(TitleProperty);
            set => SetValue(TitleProperty, value);
        }

        // Status Color Getter and Setter
        public Brush StatusColor
        {
            get => (Brush)GetValue(StatusColorProperty);
            set => SetValue(StatusColorProperty, value);
        }

        // Amperage Getter and Setter
        public string Amperage
        {
            get => (string)GetValue(AmperageProperty);
            set => SetValue(AmperageProperty, value);
        }

        // Voltage Getter and Setter
        public string Voltage
        {
            get => (string)GetValue(VoltageProperty);
            set => SetValue(VoltageProperty, value);
        }

        // Wattage Getter and Setter
        public string Wattage
        {
            get => (string)GetValue(WattageProperty);
            set => SetValue(WattageProperty, value);
        }

        public int RegisterIndex { 
            get => (int)GetValue(RegisterIndexProperty); 
            set => SetValue(RegisterIndexProperty, value); 
        }

        // Power button click handler
        private void PowerButton_Click(object sender, RoutedEventArgs e)
        {
            if (AppServices.Connection.ModbusMaster == null)
            {
                AppServices.ActivityLog.Add($"Cannot toggle outlet {RegisterIndex + 1}: Not connected.");
                MessageBox.Show("Not connected to device.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                byte slaveId = 1;
                ushort currentValue = AppServices.Connection.ModbusMaster.ReadHoldingRegisters(slaveId, (ushort)RegisterIndex, 1)[0];
                ushort newValue = (currentValue > 0) ? (ushort)0 : (ushort)1;

                AppServices.Connection.ModbusMaster.WriteSingleRegister(slaveId, (ushort)RegisterIndex, newValue);

                UpdateStatusColor(newValue > 0);

                AppServices.ActivityLog.Add($"Outlet {RegisterIndex + 1} turned {(newValue > 0 ? "ON" : "OFF")}.");
            }
            catch (Exception ex)
            {
                AppServices.ActivityLog.Add($"Failed to toggle outlet {RegisterIndex + 1}: {ex.Message}");
            }
        }

        // Method to update status color based on outlet state
        public void UpdateStatusColor(bool isOn)
        {
            StatusColor = isOn ? Brushes.LimeGreen : Brushes.Gray;
        }
    }
}