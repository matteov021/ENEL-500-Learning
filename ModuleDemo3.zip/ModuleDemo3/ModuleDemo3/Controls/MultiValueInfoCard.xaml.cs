﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ModuleDemo3.Controls
{
    public partial class MultiValueInfoCard : UserControl
    {
        // Constructor
        public MultiValueInfoCard()
        {
            InitializeComponent();
        }

        // Dependency Properties
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register(nameof(Title), typeof(string), typeof(MultiValueInfoCard));

        public static readonly DependencyProperty StatusColorProperty =
            DependencyProperty.Register(nameof(StatusColor), typeof(Brush), typeof(MultiValueInfoCard));

        public static readonly DependencyProperty AmperageProperty =
            DependencyProperty.Register(nameof(Amperage), typeof(string), typeof(MultiValueInfoCard));

        public static readonly DependencyProperty VoltageProperty =
            DependencyProperty.Register(nameof(Voltage), typeof(string), typeof(MultiValueInfoCard));

        public static readonly DependencyProperty WattageProperty =
            DependencyProperty.Register(nameof(Wattage), typeof(string), typeof(MultiValueInfoCard));

        // Title Getter and Setter
        public string Title
        {
            get => (string)GetValue(TitleProperty);
            set => SetValue(TitleProperty, value);
        }

        // Status Color Getter and Setter
        public Brush StatusColor
        {
            get => (Brush)GetValue(StatusColorProperty);
            set => SetValue(StatusColorProperty, value);
        }

        // Amperage Getter and Setter
        public string Amperage
        {
            get => (string)GetValue(AmperageProperty);
            set => SetValue(AmperageProperty, value);
        }

        // Voltage Getter and Setter
        public string Voltage
        {
            get => (string)GetValue(VoltageProperty);
            set => SetValue(VoltageProperty, value);
        }

        // Wattage Getter and Setter
        public string Wattage
        {
            get => (string)GetValue(WattageProperty);
            set => SetValue(WattageProperty, value);
        }
    }
}