﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ModuleDemo3.Controls
{
    public partial class InfoCard : UserControl
    {
        
        // Constructor
        public InfoCard()
        {
            InitializeComponent();
        }

        // Title
        public static readonly DependencyProperty TitleProperty = DependencyProperty.Register(nameof(Title), typeof(string), typeof(InfoCard));

        // Value
        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(nameof(Value), typeof(string), typeof(InfoCard));

        // Status Color
        public static readonly DependencyProperty StatusColorProperty = DependencyProperty.Register(nameof(StatusColor), typeof(Brush), typeof(InfoCard));

        // Title Getter and Setter
        public string Title
        {
            get => (string)GetValue(TitleProperty);
            set => SetValue(TitleProperty, value);
        }

        // Value Getter and Setter
        public string Value
        {
            get => (string)GetValue(ValueProperty);
            set => SetValue(ValueProperty, value);
        }

        // Status Color Getter and Setter
        public Brush StatusColor
        {
            get => (Brush)GetValue(StatusColorProperty);
            set => SetValue(StatusColorProperty, value);
        }
    }
}
