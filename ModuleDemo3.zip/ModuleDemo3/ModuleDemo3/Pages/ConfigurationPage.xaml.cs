﻿using ModuleDemo3.Controls;
using ModuleDemo3.Core;
using System.Windows;
using System.Windows.Controls;

namespace ModuleDemo3.Pages
{
    public partial class ConfigurationPage : UserControl
    {
        // Constructor
        public ConfigurationPage()
        {
            InitializeComponent();
            OutletSelector.SelectedIndex = 0;

            // Update card colors whenever registers change
            AppServices.Connection.DataReceived += data =>
            {
                Dispatcher.Invoke(() =>
                {
                    ushort[] registers = data.Split(',').Select(ushort.Parse).ToArray();

                    foreach (var card in InfoCardsPanel.Children.OfType<MultiValueInfoCard>())
                    {
                        if (card.RegisterIndex < registers.Length)
                            card.UpdateStatusColor(registers[card.RegisterIndex] > 0);
                    }
                });
            };
        }

        // Save Configuration Button Click Handler
        private void SaveConfig_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Configuration saved.\n(Will be sent to device later)",
                "Configuration",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
    }
}
