﻿using System.Windows;
using System.Windows.Controls;

namespace ModuleDemo3.Pages
{
    public partial class ConfigurationPage : UserControl
    {
        // Constructor
        public ConfigurationPage()
        {
            InitializeComponent();
            OutletSelector.SelectedIndex = 0;
        }

        // Save Configuration Button Click Handler
        private void SaveConfig_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Configuration saved.\n(Will be sent to device later)",
                "Configuration",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
    }
}
