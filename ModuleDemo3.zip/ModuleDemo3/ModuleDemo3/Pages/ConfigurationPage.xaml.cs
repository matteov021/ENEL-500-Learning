﻿using ModuleDemo3.Controls;
using ModuleDemo3.Core;
using ModuleDemo3.Core.Services;
using System.Windows;
using System.Windows.Controls;

namespace ModuleDemo3.Pages
{
    public partial class ConfigurationPage : UserControl
    {
        private const int MaxAmps = 20;

        // Initialize the page and subscribe to data updates from the device
        public ConfigurationPage()
        {
            InitializeComponent();

            OutletSelector.SelectedIndex = 0;
            LimitTypeSelector.SelectedIndex = 0;

            AppServices.Connection.DataReceived += OnDataReceived;
        }

        // Handle incoming data updates and refresh the UI accordingly
        private void OnDataReceived(string data)
        {
            Dispatcher.Invoke(() =>
            {
                ushort[] registers = data.Split(',').Select(ushort.Parse).ToArray();

                int voltage = ParseVoltage(Properties.Settings.Default.Voltage);

                foreach (var card in InfoCardsPanel.Children.OfType<MultiValueInfoCard>())
                {
                    int outlet = card.RegisterIndex;

                    if (outlet < 10)
                        card.UpdateStatusColor(registers[outlet] > 0);

                    int baseIndex = 10 + (outlet * 2);

                    if (baseIndex + 1 < registers.Length)
                    {
                        ushort high = registers[baseIndex];
                        ushort low = registers[baseIndex + 1];

                        uint amps = ConnectionService.CombineHighLow(high, low);

                        double watts = amps * voltage;

                        card.Amperage = $"{amps} A";
                        card.Voltage = $"{voltage} V";
                        card.Wattage = $"{watts} W";
                    }
                }
            });
        }

        // Utility to parse voltage from settings (e.g. "120 V" to 120)
        private int ParseVoltage(string voltageString)
        {
            string digits = new string(voltageString.Where(char.IsDigit).ToArray());
            return int.TryParse(digits, out int result) ? result : 120;
        }

        // Handle the Save button click to apply the new configuration
        private void SaveConfig_Click(object sender, RoutedEventArgs e)
        {
            
            if (!double.TryParse(LimitValueBox.Text, out double inputValue))
            {
                MessageBox.Show("Please enter a valid number.");
                return;
            }

            var modbusMaster = AppServices.Connection.ModbusMaster;
            if (modbusMaster == null)
            {
                MessageBox.Show("Not connected to device.");
                return;
            }

            bool isWattMode = ((ComboBoxItem)LimitTypeSelector.SelectedItem)
                                .Content.ToString() == "Wattage";

            int voltage = ParseVoltage(Properties.Settings.Default.Voltage);

            double amps;

            if (isWattMode)
            {
                double maxWatts = MaxAmps * voltage;

                if (inputValue < 0 || inputValue > maxWatts)
                {
                    MessageBox.Show(
                        $"Wattage must be between 0 and {maxWatts}W for {voltage}V.",
                        "Invalid Wattage",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    return;
                }

                amps = inputValue / voltage;
            }
            else
            {
                if (inputValue < 0 || inputValue > MaxAmps)
                {
                    MessageBox.Show(
                        $"Amperage must be between 0 and {MaxAmps}A.",
                        "Invalid Amperage",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    return;
                }

                amps = inputValue;
            }

            ApplyAmperageLimit(amps);
        }

        // Apply the amperage limit to the selected outlet(s) via Modbus
        private void ApplyAmperageLimit(double amps)
        {
            if (amps < 0 || amps > MaxAmps)
            {
                MessageBox.Show($"Amperage must be between 0 and {MaxAmps}A.");
                return;
            }

            byte slaveId = 1;

            uint ampValue = (uint)Math.Round(amps);

            var (high, low) = ConnectionService.SplitHighLow(ampValue);

            var modbusMaster = AppServices.Connection.ModbusMaster;
            if (modbusMaster == null)
            {
                MessageBox.Show("Not connected to device.");
                return;
            }

            if (OutletSelector.SelectedIndex == 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    ushort baseAddress = (ushort)(10 + (i * 2));

                    modbusMaster.WriteMultipleRegisters(
                        slaveId,
                        baseAddress,
                        new ushort[] { high, low });
                }

                AppServices.ActivityLog.Add($"Set ALL outlets to {ampValue}A limit.");
            }
            else
            {
                int outlet = OutletSelector.SelectedIndex - 1;
                ushort baseAddress = (ushort)(10 + (outlet * 2));

                modbusMaster.WriteMultipleRegisters(
                    slaveId,
                    baseAddress,
                    new ushort[] { high, low });

                AppServices.ActivityLog.Add($"Set Outlet {outlet + 1} to {ampValue}A limit.");
            }
        }
    }
}