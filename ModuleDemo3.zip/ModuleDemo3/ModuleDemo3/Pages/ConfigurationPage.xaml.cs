﻿using ModuleDemo3.Controls;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ModuleDemo3.Pages
{
    public partial class ConfigurationPage : UserControl
    {
        // Constructor
        public ConfigurationPage()
        {
            InitializeComponent();
            OutletSelector.SelectedIndex = 0;
        }

        // Save Configuration Button Click Handler
        private void SaveConfig_Click(object sender, RoutedEventArgs e)
        {
            if (OutletSelector.SelectedItem is not ComboBoxItem outletItem ||
                LimitTypeSelector.SelectedItem is not ComboBoxItem limitItem)
            {
                MessageBox.Show("Please select outlet and limit type.");
                return;
            }

            if (!double.TryParse(LimitValueBox.Text, out double enteredValue))
            {
                MessageBox.Show("Invalid number.");
                return;
            }

            string selectedOutlet = outletItem.Content.ToString();
            string limitType = limitItem.Content.ToString();

            if (!double.TryParse(Properties.Settings.Default.Voltage, out double voltage))
                voltage = 120;

            double maxAllowed = 20 * voltage;

            if (limitType == "Amperage")
            {
                if (enteredValue > 20)
                {
                    MessageBox.Show("Amperage cannot exceed 20A.");
                    return;
                }
            }
            else if (limitType == "Wattage")
            {
                if (enteredValue > maxAllowed)
                {
                    MessageBox.Show($"Wattage cannot exceed {maxAllowed}W.");
                    return;
                }
            }

            if (selectedOutlet == "All Outlets")
            {
                for (int i = 1; i <= 10; i++)
                {
                    ApplyLimitToCard($"Outlet {i}", limitType, enteredValue, voltage);
                }
            }
            else
            {
                ApplyLimitToCard(selectedOutlet, limitType, enteredValue, voltage);
            }
        }

        // Helper method to find visual children of a specific type
        private void ApplyLimitToCard(string outlet, string type, double value, double voltage)
        {
            foreach (var child in FindVisualChildren<MultiValueInfoCard>(this))
            {
                if (child.Title == outlet)
                {
                    if (type == "Amperage")
                    {
                        child.Amperage = $"{value} A";
                        child.Wattage = $"{value * voltage} W";
                    }
                    else
                    {
                        child.Wattage = $"{value} W";
                        child.Amperage = $"{value / voltage:F2} A";
                    }
                }
            }
        }

        // Recursive method to find visual children of a specific type
        private static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depObj, i);

                    if (child is T t)
                        yield return t;

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                        yield return childOfChild;
                }
            }
        }
    }
}
