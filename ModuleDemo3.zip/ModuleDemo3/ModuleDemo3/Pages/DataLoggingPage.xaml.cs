﻿using System.Windows;
using System.Windows.Controls;

namespace ModuleDemo3.Pages
{
    public partial class DataLoggingPage : UserControl
    {
        // Constructor
        public DataLoggingPage()
        {
            InitializeComponent();
            OutletComboBox.SelectedIndex = 0;
        }

        // Start Logging Button Click Handler
        private void StartLogging_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Data logging started.",
                "Logging",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        // Stop Logging Button Click Handler
        private void StopLogging_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Data logging stopped.",
                "Logging",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        // Export CSV Button Click Handler
        private void ExportCsv_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Exporting data to CSV (placeholder).",
                "Export",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
    }
}
