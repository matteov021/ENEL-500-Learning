﻿using Microsoft.Win32;
using ModuleDemo3.Core;
using ModuleDemo3.Core.Models;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ModuleDemo3.Pages
{
    public partial class HomePage : UserControl
    {
        // To prevent log flooding, we will only log RX data every 10 seconds at most
        private DateTime _lastRxLogTime = DateTime.MinValue;
        private readonly TimeSpan _rxLogInterval = TimeSpan.FromSeconds(10);

        // Constructor
        public HomePage()
        {
            InitializeComponent();

            AppServices.ActivityLog.LogAdded += OnLogAdded;
            AppServices.ActivityLog.LogCleared += OnLogCleared;

            AppServices.Connection.ConnectionStateChanged += state => Dispatcher.Invoke(RefreshUI);
            AppServices.Connection.DataReceived += OnDeviceDataReceived;

            RefreshUI();
        }

        // Connect button click
        private async void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            if (AppServices.Connection.CurrentState == ConnectionState.Disconnected)
            {
                string currentVoltage = Properties.Settings.Default.Voltage;
                var confirm = MessageBox.Show(
                    $"The voltage is currently set to {currentVoltage}.\n" +
                    $"Please ensure this matches your region and device configuration.\n\n" +
                    $"Do you want to continue connecting?",
                    "Confirm Voltage Before Connecting",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (confirm != MessageBoxResult.Yes)
                {
                    AppServices.ActivityLog.Add($"Connection aborted by user due to voltage confirmation ({currentVoltage}).");
                    return;
                }

                try
                {
                    AppServices.ActivityLog.Add("Attempting to connect to STM32...");
                    await AppServices.Connection.ConnectAsync();
                    AppServices.ActivityLog.Add("STM32 connected successfully.");
                }
                catch (Exception ex)
                {
                    AppServices.ActivityLog.Add($"Connection failed: {ex.Message}");
                }
            }
            else
            {
                AppServices.Connection.Disconnect();
                AppServices.ActivityLog.Add("Disconnected from STM32.");
            }

            RefreshUI();
        }

        // Power button click to toggle all outlets
        private async void PowerButton_Click(object sender, RoutedEventArgs e)
        {
            if (AppServices.Connection.ModbusMaster == null)
            {
                AppServices.ActivityLog.Add("Cannot update registers: Not connected.");
                MessageBox.Show("Not connected to device.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                byte slaveId = 1;
                var master = AppServices.Connection.ModbusMaster;

                if (AppServices.Power.CurrentState == PowerState.Active)
                {
                    // Request ALL OFF
                    ushort[] zeros = new ushort[10];
                    master.WriteMultipleRegisters(slaveId, 0, zeros);
                    ushort[] verify = master.ReadHoldingRegisters(slaveId, 0, 10);

                    if (verify.All(r => r == 0))
                    {
                        AppServices.ActivityLog.Add("All outlets turned OFF.");
                    }
                    else
                    {
                        AppServices.ActivityLog.Add("Failed to turn OFF all outlets (verification mismatch).");
                    }
                }
                else
                {
                    // Request ALL ON
                    ushort[] ones = Enumerable.Repeat((ushort)1, 10).ToArray();
                    master.WriteMultipleRegisters(slaveId, 0, ones);
                    ushort[] verify = master.ReadHoldingRegisters(slaveId, 0, 10);

                    if (verify.All(r => r == 1))
                    {
                        AppServices.ActivityLog.Add("All outlets turned ON.");
                    }
                    else
                    {
                        AppServices.ActivityLog.Add("Failed to turn ON all outlets (check current limits).");
                    }
                }
            }
            catch (Exception ex)
            {
                AppServices.ActivityLog.Add($"Failed to update registers: {ex.Message}");
            }
        }

        // Export log button click
        private void ExportLogButton_Click(object sender, RoutedEventArgs e)
        {
            if (AppServices.ActivityLog.Logs.Count == 0)
            {
                MessageBox.Show("No log entries to export.");
                return;
            }

            var dialog = new SaveFileDialog
            {
                Filter = "CSV Files (*.csv)|*.csv",
                FileName = $"activity_log_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };

            if (dialog.ShowDialog() == true)
            {
                AppServices.ActivityLog.ExportCsv(dialog.FileName);
                MessageBox.Show("Log exported successfully.", "Export Complete", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // Clear log button click
        private void ClearLogButton_Click(object sender, RoutedEventArgs e)
        {
            AppServices.ActivityLog.Clear();
            AppServices.ActivityLog.Add("Activity log cleared.");
        }

        // Handle incoming data from the device
        private void OnDeviceDataReceived(string data)
        {
            Dispatcher.Invoke(() =>
            {
                try
                {
                    ushort[] registers = data.Split(',').Select(r => ushort.Parse(r.Trim())).ToArray();

                    if (DateTime.Now - _lastRxLogTime > _rxLogInterval)
                    {
                        string firstTen = string.Join(",", registers.Take(10));
                        AppServices.ActivityLog.Add($"RX Outlet States (0–9): {firstTen}");
                        _lastRxLogTime = DateTime.Now;
                    }

                    AppServices.Power.UpdateFromRegisters(registers);

                    RefreshUI();
                }
                catch (Exception ex)
                {
                    AppServices.ActivityLog.Add($"Failed to parse registers: {ex.Message}");
                }
            });
        }

        private void OnLogAdded(string log)
        {
            ActivityList.Items.Add(log);
            ActivityList.ScrollIntoView(ActivityList.Items[^1]);
        }

        private void OnLogCleared()
        {
            ActivityList.Items.Clear();
        }

        private void RefreshUI()
        {
            UpdateConnectionCard();
            UpdateStatusCard();
            UpdateSystemCard();
        }

        private void UpdateConnectionCard()
        {
            switch (AppServices.Connection.CurrentState)
            {
                case ConnectionState.Disconnected:
                    ConnectionCard.Value = "Disconnected";
                    ConnectionCard.StatusColor = Brushes.Red;
                    break;
                case ConnectionState.Connecting:
                    ConnectionCard.Value = "Connecting";
                    ConnectionCard.StatusColor = Brushes.Orange;
                    break;
                case ConnectionState.Connected:
                    ConnectionCard.Value = "Connected";
                    ConnectionCard.StatusColor = Brushes.LimeGreen;
                    break;
            }
        }

        private void UpdateStatusCard()
        {
            switch (AppServices.Power.CurrentState)
            {
                case PowerState.Idle:
                    StatusCard.Value = "Idle";
                    StatusCard.StatusColor = Brushes.Orange;
                    break;
                case PowerState.Active:
                    StatusCard.Value = "Active";
                    StatusCard.StatusColor = Brushes.LimeGreen;
                    break;
            }
        }

        private void UpdateSystemCard()
        {
            switch (AppServices.SystemStatus.CurrentState)
            {
                case SystemState.Normal:
                    SystemCard.Value = "Normal";
                    SystemCard.StatusColor = Brushes.LimeGreen;
                    break;
                case SystemState.Issue:
                    SystemCard.Value = "Issue";
                    SystemCard.StatusColor = Brushes.Red;
                    break;
            }
        }
    }
}