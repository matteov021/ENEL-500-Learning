﻿using Microsoft.Win32;
using ModuleDemo3.Core;
using ModuleDemo3.Core.Models;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ModuleDemo3.Pages
{
    public partial class HomePage : UserControl
    {
        public HomePage()
        {
            InitializeComponent();

            AppServices.ActivityLog.LogAdded += OnLogAdded;
            AppServices.ActivityLog.LogCleared += OnLogCleared;

            AppServices.Connection.ConnectionStateChanged += state => Dispatcher.Invoke(RefreshUI);
            AppServices.Connection.DataReceived += OnDeviceDataReceived;

            RefreshUI();
        }

        // Connect button click
        private async void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            if (AppServices.Connection.CurrentState == ConnectionState.Disconnected)
            {
                try
                {
                    AppServices.ActivityLog.Add("Attempting to connect to STM32...");
                    await AppServices.Connection.ConnectAsync();
                    AppServices.ActivityLog.Add("STM32 connected successfully.");
                }
                catch (Exception ex)
                {
                    AppServices.ActivityLog.Add($"Connection failed: {ex.Message}");
                }
            }
            else
            {
                AppServices.Connection.Disconnect();
                AppServices.ActivityLog.Add("Disconnected from STM32.");
            }

            RefreshUI();
        }

        // Power button click
        private async void PowerButton_Click(object sender, RoutedEventArgs e)
        {
            if (AppServices.Connection.ModbusMaster == null)
            {
                AppServices.ActivityLog.Add("Cannot update registers: Not connected.");
                MessageBox.Show("Not connected to device.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                byte slaveId = 1;

                if (AppServices.Power.CurrentState == PowerState.Active)
                {
                    // Turn ALL OFF
                    ushort[] zeros = new ushort[10];
                    AppServices.Connection.ModbusMaster.WriteMultipleRegisters(slaveId, 0, zeros);
                    AppServices.ActivityLog.Add("All outlets turned OFF.");
                }
                else
                {
                    // Turn ALL ON
                    ushort[] ones = Enumerable.Repeat((ushort)1, 10).ToArray();
                    AppServices.Connection.ModbusMaster.WriteMultipleRegisters(slaveId, 0, ones);
                    AppServices.ActivityLog.Add("All outlets turned ON.");
                }
            }
            catch (Exception ex)
            {
                AppServices.ActivityLog.Add($"Failed to update registers: {ex.Message}");
            }
        }

        private void ExportLogButton_Click(object sender, RoutedEventArgs e)
        {
            if (AppServices.ActivityLog.Logs.Count == 0)
            {
                MessageBox.Show("No log entries to export.");
                return;
            }

            var dialog = new SaveFileDialog
            {
                Filter = "CSV Files (*.csv)|*.csv",
                FileName = $"activity_log_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };

            if (dialog.ShowDialog() == true)
            {
                AppServices.ActivityLog.ExportCsv(dialog.FileName);
                MessageBox.Show("Log exported successfully.", "Export Complete", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ClearLogButton_Click(object sender, RoutedEventArgs e)
        {
            AppServices.ActivityLog.Clear();
            AppServices.ActivityLog.Add("Activity log cleared.");
        }

        // Handle incoming data from the device

        private void OnDeviceDataReceived(string data)
        {
            Dispatcher.Invoke(() =>
            {
                // Log raw data
                AppServices.ActivityLog.Add($"RX: {data}");

                try
                {
                    // Convert CSV string → ushort[]
                    ushort[] registers = data.Split(',').Select(r => ushort.Parse(r.Trim())).ToArray();

                    // Update power state from first 10 registers
                    AppServices.Power.UpdateFromRegisters(registers);

                    RefreshUI();
                }
                catch (Exception ex)
                {
                    AppServices.ActivityLog.Add($"Failed to parse registers: {ex.Message}");
                }
            });
        }

        private void OnLogAdded(string log)
        {
            ActivityList.Items.Add(log);
            ActivityList.ScrollIntoView(ActivityList.Items[^1]);
        }

        private void OnLogCleared()
        {
            ActivityList.Items.Clear();
        }

        private void RefreshUI()
        {
            UpdateConnectionCard();
            UpdateStatusCard();
            UpdateSystemCard();
        }

        private void UpdateConnectionCard()
        {
            switch (AppServices.Connection.CurrentState)
            {
                case ConnectionState.Disconnected:
                    ConnectionCard.Value = "Disconnected";
                    ConnectionCard.StatusColor = Brushes.Red;
                    break;
                case ConnectionState.Connecting:
                    ConnectionCard.Value = "Connecting";
                    ConnectionCard.StatusColor = Brushes.Orange;
                    break;
                case ConnectionState.Connected:
                    ConnectionCard.Value = "Connected";
                    ConnectionCard.StatusColor = Brushes.LimeGreen;
                    break;
            }
        }

        private void UpdateStatusCard()
        {
            switch (AppServices.Power.CurrentState)
            {
                case PowerState.Idle:
                    StatusCard.Value = "Idle";
                    StatusCard.StatusColor = Brushes.Orange;
                    break;
                case PowerState.Active:
                    StatusCard.Value = "Active";
                    StatusCard.StatusColor = Brushes.LimeGreen;
                    break;
            }
        }

        private void UpdateSystemCard()
        {
            switch (AppServices.SystemStatus.CurrentState)
            {
                case SystemState.Normal:
                    SystemCard.Value = "Normal";
                    SystemCard.StatusColor = Brushes.LimeGreen;
                    break;
                case SystemState.Issue:
                    SystemCard.Value = "Issue";
                    SystemCard.StatusColor = Brushes.Red;
                    break;
            }
        }
    }
}