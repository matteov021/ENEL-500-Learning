﻿using ModuleDemo3.Core.Models;
using ModuleDemo3.Core.Services;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ModuleDemo3.Pages
{
    // Home Page
    public partial class HomePage : UserControl
    {
        // Services
        private readonly ConnectionService _connectionService;
        private readonly PowerService _powerService;
        private readonly SystemStatusService _systemService;

        // Constructor
        public HomePage()
        {
            InitializeComponent();

            _connectionService = new ConnectionService();
            _powerService = new PowerService();
            _systemService = new SystemStatusService();

            RefreshUI();
        }

        // Connect Button Click Event
        private async void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateConnectionUI(ConnectionState.Connecting);

            bool success = await _connectionService.ConnectAsync();

            UpdateConnectionUI(_connectionService.CurrentState);
            RefreshUI();
        }

        // Power Button Click Event
        private void PowerButton_Click(object sender, RoutedEventArgs e)
        {
            // Toggle Power State
            if (_powerService.CurrentState == PowerState.Off)
                _powerService.PowerOn();
            else
                _powerService.PowerOff();

            RefreshUI();
        }

        // Refresh UI Method
        private void RefreshUI()
        {
            // Update Power Status
            switch (_powerService.CurrentState)
            {
                case PowerState.Off:
                    SetStatus("Inactive", Brushes.Red);
                    break;

                case PowerState.Idle:
                    SetStatus("Idle", Brushes.Orange);
                    break;

                case PowerState.Active:
                    SetStatus("Active", Brushes.LimeGreen);
                    break;
            }

            UpdateConnectionUI(_connectionService.CurrentState);

            // Update System Status
            if (_systemService.CurrentState == SystemState.Normal)
                SetSystem("Normal", Brushes.LimeGreen);
            else
                SetSystem("Issue", Brushes.Red);
        }

        // Update Connection UI Method
        private void UpdateConnectionUI(ConnectionState state)
        {
            // Update Connection Status
            switch (state)
            {
                case ConnectionState.Disconnected:
                    ConnectionCard.Value = "Disconnected";
                    ConnectionCard.StatusColor = Brushes.Red;
                    break;

                case ConnectionState.Connecting:
                    ConnectionCard.Value = "Connecting...";
                    ConnectionCard.StatusColor = Brushes.Orange;
                    break;

                case ConnectionState.Connected:
                    ConnectionCard.Value = "Connected";
                    ConnectionCard.StatusColor = Brushes.LimeGreen;
                    break;
            }
        }

        private void SetStatus(string text, Brush color)
        {
            // Can Implement later
        }

        private void SetSystem(string text, Brush color)
        {
            // Can Implement later
        }
    }
}
