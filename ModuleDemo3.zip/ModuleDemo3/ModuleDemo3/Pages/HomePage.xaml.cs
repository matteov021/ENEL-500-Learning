﻿using ModuleDemo3.Core.Models;
using ModuleDemo3.Core.Services;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ModuleDemo3.Pages
{
    // Interaction logic for HomePage.xaml
    public partial class HomePage : UserControl
    {
        private readonly ConnectionService _connectionService;
        private readonly PowerService _powerService;
        private readonly SystemStatusService _systemService;
        private readonly ActivityLogService _activityLogService;

        // Constructor
        public HomePage()
        {
            InitializeComponent();

            // Initialize services
            _connectionService = new ConnectionService();
            _powerService = new PowerService();
            _systemService = new SystemStatusService();
            _activityLogService = new ActivityLogService();

            // Subscribe to activity log events
            _activityLogService.LogAdded += OnLogAdded;
            _activityLogService.LogCleared += OnLogCleared;

            RefreshUI();
        }

        // Connect button click handler
        private async void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            _activityLogService.Add("Attempting to connect to device...");
            await _connectionService.ConnectAsync();
            _activityLogService.Add("Device connected successfully.");
            RefreshUI();
        }

        // Power button click handler
        private void PowerButton_Click(object sender, RoutedEventArgs e)
        {
            _powerService.TogglePower();
            _activityLogService.Add(_powerService.CurrentState == PowerState.Off ? "Power disabled." : "Power enabled.");
            RefreshUI();
        }

        // Clear log button click handler
        private void ClearLogButton_Click(object sender, RoutedEventArgs e)
        {
            _activityLogService.Clear();
            _activityLogService.Add("Activity log cleared.");
        }

        // Refresh the UI based on current states
        private void RefreshUI()
        {
            UpdateConnectionCard();
            UpdateStatusCard();
            UpdateSystemCard();
        }

        // Add entry to activity log
        private void OnLogAdded(string log)
        {
            ActivityList.Items.Add(log);
            ActivityList.ScrollIntoView(ActivityList.Items[^1]);
        }

        // Clear activity log
        private void OnLogCleared()
        {
            ActivityList.Items.Clear();
        }

        // Update connection status card
        private void UpdateConnectionCard()
        {
            switch (_connectionService.CurrentState)
            {
                case ConnectionState.Disconnected:
                    ConnectionCard.Value = "Disconnected";
                    ConnectionCard.StatusColor = Brushes.Red;
                    break;

                case ConnectionState.Connecting:
                    ConnectionCard.Value = "Connecting";
                    ConnectionCard.StatusColor = Brushes.Orange;
                    break;

                case ConnectionState.Connected:
                    ConnectionCard.Value = "Connected";
                    ConnectionCard.StatusColor = Brushes.LimeGreen;
                    break;
            }
        }

        // Update power status card
        private void UpdateStatusCard()
        {
            switch (_powerService.CurrentState)
            {
                case PowerState.Off:
                    StatusCard.Value = "Inactive";
                    StatusCard.StatusColor = Brushes.Red;
                    break;

                case PowerState.Idle:
                    StatusCard.Value = "Idle";
                    StatusCard.StatusColor = Brushes.Orange;
                    break;

                case PowerState.Active:
                    StatusCard.Value = "Active";
                    StatusCard.StatusColor = Brushes.LimeGreen;
                    break;
            }
        }

        // Update system status card
        private void UpdateSystemCard()
        {
            if (_systemService.CurrentState == SystemState.Normal)
            {
                SystemCard.Value = "Normal";
                SystemCard.StatusColor = Brushes.LimeGreen;
            }
            else
            {
                SystemCard.Value = "Issue";
                SystemCard.StatusColor = Brushes.Red;
            }
        }
    }
}
