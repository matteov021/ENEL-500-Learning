﻿using Microsoft.Win32;
using System.Windows;
using System.Windows.Controls;

namespace ModuleDemo3.Pages
{
    public partial class SettingsPage : UserControl
    {
        // Firmware file path
        private string? _firmwarePath;

        // Constructor
        public SettingsPage()
        {
            InitializeComponent();
            VoltageSelector.SelectedIndex = 0;
            ThemeSelector.SelectedIndex = 0;
        }

        // Select Firmware Button Click Handler
        private void SelectFirmware_Click(object sender, RoutedEventArgs e)
        {
            // Open file dialog for firmware selection
            var dialog = new OpenFileDialog
            {
                Filter = "Firmware Files (*.bin;*.hex)|*.bin;*.hex",
                Title = "Select Firmware File"
            };

            // Show dialog and handle file selection
            if (dialog.ShowDialog() == true)
            {
                _firmwarePath = dialog.FileName;
                FirmwarePathText.Text = dialog.FileName;
                FirmwarePathText.Foreground = System.Windows.Media.Brushes.Black;
                FlashButton.IsEnabled = true;
            }
        }

        // Flash Firmware Button Click Handler
        private void FlashFirmware_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(
                                        "Flashing firmware can take several minutes.\nDo not disconnect the device.\n\nContinue?",
                                        "Confirm Firmware Flash", 
                                         MessageBoxButton.YesNo, 
                                         MessageBoxImage.Warning);

            if (result != MessageBoxResult.Yes)
                return;

            MessageBox.Show(
                            $"Firmware flashing started.\n\nFile:\n{_firmwarePath}", 
                            "Flashing", 
                            MessageBoxButton.OK, 
                            MessageBoxImage.Information);
        }

        // Save Settings Button Click Handler
        private void SaveSettings_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                            "Settings have been saved.", 
                            "Settings", 
                            MessageBoxButton.OK, 
                            MessageBoxImage.Information);
        }

    }
}
