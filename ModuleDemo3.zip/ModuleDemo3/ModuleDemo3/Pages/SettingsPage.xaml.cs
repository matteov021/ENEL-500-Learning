﻿using Microsoft.Win32;
using ModuleDemo3.Core;
using System.Windows;
using System.Windows.Controls;

namespace ModuleDemo3.Pages
{
    public partial class SettingsPage : UserControl
    {
        // Firmware file path
        private string? _firmwarePath;

        // Constructor
        public SettingsPage()
        {
            InitializeComponent();
            
            var savedVoltage = Properties.Settings.Default.Voltage;
            VoltageSelector.SelectedIndex = savedVoltage == "120 V" ? 0 : 1;

            var savedTheme = Properties.Settings.Default.Theme;
            ThemeSelector.SelectedIndex = savedTheme == "Dark" ? 0 : 1;
        }

        // Select Firmware Button Click Handler
        private void SelectFirmware_Click(object sender, RoutedEventArgs e)
        {
            // Open file dialog for firmware selection
            var dialog = new OpenFileDialog
            {
                Filter = "Firmware Files (*.bin;*.hex)|*.bin;*.hex",
                Title = "Select Firmware File"
            };

            // Show dialog and handle file selection
            if (dialog.ShowDialog() == true)
            {
                _firmwarePath = dialog.FileName;
                FirmwarePathText.Text = dialog.FileName;
                FlashButton.IsEnabled = true;
            }
        }

        // Flash Firmware Button Click Handler
        private void FlashFirmware_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(
                                        "Flashing firmware can take several minutes.\nDo not disconnect the device.\n\nContinue?",
                                        "Confirm Firmware Flash", 
                                         MessageBoxButton.YesNo, 
                                         MessageBoxImage.Warning);

            if (result != MessageBoxResult.Yes)
                return;

            MessageBox.Show(
                            $"Firmware flashing started.\n\nFile:\n{_firmwarePath}", 
                            "Flashing", 
                            MessageBoxButton.OK, 
                            MessageBoxImage.Information);
        }

        // Save Settings Button Click Handler
        private void SaveSettings_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                            "Settings have been saved.", 
                            "Settings", 
                            MessageBoxButton.OK, 
                            MessageBoxImage.Information);
        }

        // Theme Selector Change Handler
        private void ThemeSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!IsLoaded) 
                return;

            var selected = (ThemeSelector.SelectedItem as ComboBoxItem)?.Content?.ToString();

            if (selected == null) 
                return;

            ((App)Application.Current).SetTheme(selected);

            Properties.Settings.Default.Theme = selected;
            Properties.Settings.Default.Save();
        }

        // Voltage Selector Change Handler
        private void VoltageSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!IsLoaded)
                return;

            var selected = (VoltageSelector.SelectedItem as ComboBoxItem)?.Content?.ToString();
            if (selected == null)
                return;

            if (selected != Properties.Settings.Default.Voltage)
            {
                var result = MessageBox.Show(
                    $"Changing voltage from {Properties.Settings.Default.Voltage} to {selected} is a significant change.\nAre you sure you want to continue?",
                    "Confirm Voltage Change",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result != MessageBoxResult.Yes)
                {
                    VoltageSelector.SelectionChanged -= VoltageSelector_SelectionChanged;
                    VoltageSelector.SelectedItem = (selected == "120 V")
                                                    ? VoltageSelector.Items[1]
                                                    : VoltageSelector.Items[0];
                    VoltageSelector.SelectionChanged += VoltageSelector_SelectionChanged;
                    return;
                }
            }

            Properties.Settings.Default.Voltage = selected;
            Properties.Settings.Default.Save();
            AppServices.ActivityLog.Add($"Voltage changed to {selected}");
        }
    }
}
