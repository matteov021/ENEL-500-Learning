﻿using System.Windows;
using System.Windows.Controls;

namespace ModuleDemo3.Pages
{
    public partial class GraphsPage : UserControl
    {
        // Constructor
        public GraphsPage()
        {
            InitializeComponent();
            OutletComboBox.SelectedIndex = 0;
            ApplyOutlet();
        }

        // Apply selected outlet settings
        private void ApplyOutlet()
        {
            // Update cards and graph status based on selected outlet
            if (OutletComboBox.SelectedIndex == 0)
            {
                PowerCard.Value = "10 W";
                CurrentCard.Value = "20 A";
                VoltageCard.Value = "5 V";
                GraphStatusText.Text = "Graph for Outlet 1";
            }
            else if (OutletComboBox.SelectedIndex == 1)
            {
                PowerCard.Value = "50 W";
                CurrentCard.Value = "40 A";
                VoltageCard.Value = "10 V";
                GraphStatusText.Text = "Graph for Outlet 2";
            }
        }

        // Apply Outlet Button Click Handler
        private void ApplyOutlet_Click(object sender, RoutedEventArgs e)
        {
            ApplyOutlet();
            MessageBox.Show(
                            "Settings have been saved.",
                            "Settings",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
        }
    }
}
