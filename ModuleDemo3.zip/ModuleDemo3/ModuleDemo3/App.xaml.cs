﻿using System.Windows;

namespace ModuleDemo3
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {

        // Set the application theme (Light or Dark)
        public void SetTheme(string theme)
        {
            var dictionaries = Resources.MergedDictionaries;

            var oldTheme = dictionaries
                .FirstOrDefault(d => d.Source != null &&
                                     d.Source.OriginalString.Contains("Theme"));

            if (oldTheme != null)
                dictionaries.Remove(oldTheme);

            var newTheme = new ResourceDictionary();

            newTheme.Source = theme == "Dark"
                ? new Uri("Themes/Dark.xaml", UriKind.Relative)
                : new Uri("Themes/Light.xaml", UriKind.Relative);

            dictionaries.Add(newTheme);
        }

        // Save the selected theme to application settings on exit
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            var savedTheme = ModuleDemo3.Properties.Settings.Default.Theme;

            SetTheme(savedTheme);
        }
    }
}
