﻿namespace ModuleDemo3.Core.Models
{
    // Device connection states
    public enum ConnectionState
    {
        Disconnected,
        Connecting,
        Connected
    }

    // Device power states
    public enum PowerState
    {
        Off,
        Idle,
        Active
    }

    // System operational states
    public enum SystemState
    {
        Normal,
        Issue
    }
}
