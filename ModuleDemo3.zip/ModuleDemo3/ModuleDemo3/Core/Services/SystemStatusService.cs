﻿using ModuleDemo3.Core.Models;

namespace ModuleDemo3.Core.Services
{
    public class SystemStatusService
    {
        public SystemState CurrentState { get; private set; } = SystemState.Normal;

        public void Evaluate()
        {
            // Placeholder for:
            // - Error flags from STM32
            // - Overcurrent / fault states
            // - Watchdog timeouts
        }
    }
}
