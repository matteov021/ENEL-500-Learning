﻿using ModuleDemo3.Core.Models;

namespace ModuleDemo3.Core.Services
{
    // Service to monitor system status
    public class SystemStatusService
    {
        // Current system state
        public SystemState CurrentState => SystemState.Normal;
    }
}
