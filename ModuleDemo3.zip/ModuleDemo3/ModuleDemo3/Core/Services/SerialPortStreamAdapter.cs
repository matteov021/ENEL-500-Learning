﻿using System.IO.Ports;
using NModbus.IO;

namespace ModuleDemo3.Core.Services
{
    // Adapter to wrap SerialPort as an IStreamResource for NModbus
    public class SerialPortStreamAdapter : IStreamResource
    {
        // NModbus uses this to read/write data and manage timeouts
        private readonly SerialPort _serialPort;

        public SerialPortStreamAdapter(SerialPort serialPort)
        {
            _serialPort = serialPort;
        }

        // NModbus uses this to set infinite timeouts
        public int InfiniteTimeout => Timeout.Infinite;

        // NModbus uses this to clear buffers before communication
        public void DiscardInBuffer() => _serialPort.DiscardInBuffer();

        // NModbus uses this to clear buffers before communication
        public void DiscardOutBuffer() => _serialPort.DiscardOutBuffer();

        // NModbus uses these to manage read/write timeouts
        public int ReadTimeout
        {
            get => _serialPort.ReadTimeout;
            set => _serialPort.ReadTimeout = value;
        }

        // NModbus uses these to manage read/write timeouts
        public int WriteTimeout
        {
            get => _serialPort.WriteTimeout;
            set => _serialPort.WriteTimeout = value;
        }

        // NModbus uses this to dispose of the stream when done
        public void Dispose() => _serialPort?.Dispose();

        // NModbus uses this to read data from the serial port
        public int Read(byte[] buffer, int offset, int count)
        {
            return _serialPort.Read(buffer, offset, count);
        }

        // NModbus uses this to write data to the serial port
        public void Write(byte[] buffer, int offset, int count)
        {
            _serialPort.Write(buffer, offset, count);
        }

        // NModbus uses this to read data asynchronously
        public Task<int> ReadAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken)
        {
            return _serialPort.BaseStream.ReadAsync(buffer, offset, count, cancellationToken);
        }

        // NModbus uses this to write data asynchronously
        public Task WriteAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken)
        {
            return _serialPort.BaseStream.WriteAsync(buffer, offset, count, cancellationToken);
        }

        // NModbus uses this to ensure all data is sent
        public void Flush() => _serialPort.BaseStream.Flush();

        // NModbus uses this to check if the stream can be read from
        public void Close()
        {
            if (_serialPort.IsOpen)
                _serialPort.Close();
        }

        // NModbus uses this to check if the stream is open
        public bool IsOpen => _serialPort.IsOpen;
    }
}