﻿namespace ModuleDemo3.Core.Services
{
    public class ActivityLogService
    {
        public event Action<string>? LogAdded;
        public event Action? LogCleared;

        // Add a new entry to the activity log
        public void Add(string message)
        {
            string timestamp = DateTime.Now.ToString("HH:mm:ss");
            LogAdded?.Invoke($"[{timestamp}] {message}");
        }

        // Clear the activity log
        public void Clear()
        {
            LogCleared?.Invoke();
        }
    }
}
