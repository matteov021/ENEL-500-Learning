﻿using System.IO;
using System.Text;

namespace ModuleDemo3.Core.Services
{
    public class ActivityLogService
    {
        // Events for HomePage
        public event Action<string>? LogAdded;
        public event Action? LogCleared;
        private readonly List<string> _logs = new();

        // Read-only access to logs
        public IReadOnlyList<string> Logs => _logs;

        // Adds a log entry with a timestamp
        public void Add(string message)
        {
            string timestamp = DateTime.Now.ToString("HH:mm:ss");
            string entry = $"[{timestamp}] {message}";

            _logs.Add(entry);
            LogAdded?.Invoke(entry);
        }

        // Clears all log entries
        public void Clear()
        {
            _logs.Clear();
            LogCleared?.Invoke();
        }

        // Exports logs to a CSV file
        public void ExportCsv(string filePath)
        {
            var sb = new StringBuilder();
            sb.AppendLine("LogEntry");

            foreach (var log in _logs)
            {
                string safe = log.Replace("\"", "\"\"");
                sb.AppendLine($"\"{safe}\"");
            }

            File.WriteAllText(filePath, sb.ToString());
        }
    }
}
