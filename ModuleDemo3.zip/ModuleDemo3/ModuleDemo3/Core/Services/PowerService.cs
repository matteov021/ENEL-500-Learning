﻿using ModuleDemo3.Core.Models;

namespace ModuleDemo3.Core.Services
{
    public class PowerService
    {
        public PowerState CurrentState { get; private set; } = PowerState.Off;

        public void TogglePower()
        {
            // Placeholder for:
            // - Sending power enable/disable command
            // - Validating safety conditions

            if (CurrentState == PowerState.Off)
                CurrentState = PowerState.Idle;
            else
                CurrentState = PowerState.Off;
        }
    }
}
