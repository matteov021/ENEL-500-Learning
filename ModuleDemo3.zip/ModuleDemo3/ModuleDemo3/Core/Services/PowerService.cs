﻿using ModuleDemo3.Core.Models;

namespace ModuleDemo3.Core.Services
{
    // Service to manage device power states
    public class PowerService
    {
        // Current power state
        public PowerState CurrentState { get; private set; } = PowerState.Off;

        // Method to power on the device
        public void PowerOn()
        {
            CurrentState = PowerState.Idle;
        }

        // Method to power off the device
        public void PowerOff()
        {
            CurrentState = PowerState.Off;
        }
    }
}
