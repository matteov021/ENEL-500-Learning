﻿using ModuleDemo3.Core.Models;
public class PowerService
{
    public PowerState CurrentState { get; private set; } = PowerState.Idle;
    public event Action<PowerState>? PowerStateChanged;

    public void UpdateFromRegisters(ushort[] registers)
    {
        bool anyActive = registers.Take(10).Any(r => r > 0);
        var newState = anyActive ? PowerState.Active : PowerState.Idle;

        if (newState != CurrentState)
        {
            CurrentState = newState;
            PowerStateChanged?.Invoke(CurrentState);
        }
    }
}