﻿using ModuleDemo3.Core.Services;

namespace ModuleDemo3.Core
{
    public static class AppServices
    {
        // Centralized access to all core services
        public static ConnectionService Connection { get; } = new ConnectionService();
        public static PowerService Power { get; } = new PowerService();
        public static SystemStatusService SystemStatus { get; } = new SystemStatusService();
        public static ActivityLogService ActivityLog { get; } = new ActivityLogService();
    }
}