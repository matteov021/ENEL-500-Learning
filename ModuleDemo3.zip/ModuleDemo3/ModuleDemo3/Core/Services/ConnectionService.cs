﻿using ModuleDemo3.Core.Models;

namespace ModuleDemo3.Core.Services
{
    public class ConnectionService
    {
        public ConnectionState CurrentState { get; private set; } = ConnectionState.Disconnected;

        public async Task ConnectAsync()
        {
            // Placeholder for:
            // - Opening serial port
            // - Handshake with STM32
            // - Timeout / retry logic

            CurrentState = ConnectionState.Connecting;
            await Task.Delay(1000);

            CurrentState = ConnectionState.Connected;
        }

        public void Disconnect()
        {
            // Placeholder for:
            // - Closing serial port
            // - Cleaning resources

            CurrentState = ConnectionState.Disconnected;
        }
    }
}
