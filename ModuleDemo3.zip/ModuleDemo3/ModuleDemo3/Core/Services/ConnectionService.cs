﻿using System.IO.Ports;
using ModuleDemo3.Core.Models;
using NModbus;

namespace ModuleDemo3.Core.Services
{
    public class ConnectionService
    {
        // Serial port and Modbus master instances
        private SerialPort? _serialPort;
        private IModbusSerialMaster? _modbusMaster;

        // Expose Modbus master for direct use in other services
        public IModbusSerialMaster? ModbusMaster => _modbusMaster;

        // Current connection state
        public ConnectionState CurrentState { get; private set; } = ConnectionState.Disconnected;

        // Events for HomePage
        public event Action<string>? DataReceived;
        public event Action<ConnectionState>? ConnectionStateChanged;

        // Attempt to connect to the STM32 device over serial ports
        public async Task ConnectAsync(int baudRate = 48000, byte slaveId = 1)
        {
            if (CurrentState == ConnectionState.Connected)
                return;

            CurrentState = ConnectionState.Connecting;
            ConnectionStateChanged?.Invoke(CurrentState);
            await Task.Delay(100);

            string[] ports = SerialPort.GetPortNames();

            foreach (var port in ports)
            {
                try
                {
                    var serial = new SerialPort(port)
                    {
                        BaudRate = baudRate,
                        Parity = Parity.None,
                        DataBits = 8,
                        StopBits = StopBits.One,
                        ReadTimeout = 1000,
                        WriteTimeout = 1000
                    };

                    serial.Open();

                    var adapter = new SerialPortStreamAdapter(serial);
                    var factory = new ModbusFactory();
                    var master = factory.CreateRtuMaster(adapter);
                    master.Transport.ReadTimeout = 1000;

                    try
                    {
                        var test = master.ReadHoldingRegisters(slaveId, 0, 1);
                    }
                    catch
                    {
                        serial.Close();
                        continue;
                    }

                    _serialPort = serial;
                    _modbusMaster = master;

                    CurrentState = ConnectionState.Connected;
                    ConnectionStateChanged?.Invoke(CurrentState);

                    // Optionally start a polling loop for Modbus data
                    _ = Task.Run(() => PollLoop(slaveId));

                    return;
                }
                catch
                {
                    try { _serialPort?.Close(); } catch { }
                }
            }

            CurrentState = ConnectionState.Disconnected;
            ConnectionStateChanged?.Invoke(CurrentState);
            throw new Exception("No STM32 Modbus device found.");
        }

        // Disconnect and clean up resources
        public void Disconnect()
        {
            CurrentState = ConnectionState.Disconnected;
            Task.Delay(50).Wait();

            if (_serialPort?.IsOpen == true)
            {
                _serialPort.DiscardInBuffer();
                _serialPort.DiscardOutBuffer();
                _serialPort.Close();
                _serialPort.Dispose();
            }

            _modbusMaster = null;
            ConnectionStateChanged?.Invoke(CurrentState);
        }

        // Combine two 16-bit Modbus registers into a single 32-bit float
        public static float CombineFloat(ushort high, ushort low)
        {
            byte[] bytes = new byte[4];

            // Modbus is Big Endian register order
            bytes[0] = (byte)(high >> 8);
            bytes[1] = (byte)(high & 0xFF);
            bytes[2] = (byte)(low >> 8);
            bytes[3] = (byte)(low & 0xFF);

            return BitConverter.ToSingle(bytes.Reverse().ToArray(), 0);
        }

        // Split a float into two 16-bit Modbus registers (high and low)
        public static (ushort high, ushort low) SplitFloat(float value)
        {
            byte[] bytes = BitConverter.GetBytes(value).Reverse().ToArray();

            ushort high = (ushort)((bytes[0] << 8) | bytes[1]);
            ushort low = (ushort)((bytes[2] << 8) | bytes[3]);

            return (high, low);
        }

        // Simple polling loop to read data from the device
        private async Task PollLoop(byte slaveId)
        {
            while (CurrentState == ConnectionState.Connected)
            {
                try
                {
                    // Poll 0–40 (41 registers)
                    ushort[] registers = ModbusMaster!.ReadHoldingRegisters(slaveId, 0, 41);
                    DataReceived?.Invoke(string.Join(",", registers));
                }
                catch (Exception ex)
                {
                    AppServices.ActivityLog.Add($"PollLoop error: {ex.Message}");
                }

                await Task.Delay(100);
            }
        }
    }
}