﻿using ModuleDemo3.Core.Models;

namespace ModuleDemo3.Core.Services
{
    // Service to manage device connections
    public class ConnectionService
    {
        // Current connection state
        public ConnectionState CurrentState { get; private set; } = ConnectionState.Disconnected;

        // Connect to a device asynchronously
        public async Task<bool> ConnectAsync()
        {
            CurrentState = ConnectionState.Connecting;
            await Task.Delay(1000);
            CurrentState = ConnectionState.Connected;
            return true;
        }

        // Disconnect from the device
        public void Disconnect()
        {
            CurrentState = ConnectionState.Disconnected;
        }
    }
}
