﻿using System.Windows.Controls;
using System.Windows.Media;

namespace WPFApp3.Controls
{
    public partial class InfoCard : UserControl
    {
        public string Title { get; set; }
        public string Value { get; set; }
        public Brush StatusColor { get; set; } = Brushes.Green;

        public InfoCard()
        {
            InitializeComponent();
            DataContext = this;
        }
    }
}
