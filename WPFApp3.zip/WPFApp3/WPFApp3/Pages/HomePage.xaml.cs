﻿using System.Windows.Controls;

namespace WPFApp3.Pages
{
    public partial class HomePage : UserControl
    {
        public HomePage()
        {
            InitializeComponent();
        }
    }
}
